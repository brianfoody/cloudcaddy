# Bundling

`tar --exclude='.git/' -cvzf  cloudcaddy-0.0.6.tar.gz ./`
