# Bundling

`tar --exclude='.git/' -cvzf  cloudcaddy-0.0.3.tar.gz ./`
