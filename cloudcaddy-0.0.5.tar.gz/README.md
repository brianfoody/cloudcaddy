# Bundling

`tar --exclude='.git/' -cvzf  cloudcaddy-0.0.5.tar.gz ./`
