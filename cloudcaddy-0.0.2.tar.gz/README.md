# Bundling

`tar -cvzf  cloudcaddy-0.0.2.tar.gz ./`
